﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Selenium
{
    class Demo_bad
    {
        IWebDriver driver;

        [SetUp]
        public void StartBrowser()
        {
            driver = new ChromeDriver("C:\\Users\\username\\Desktop\\WebDrivers\\chromedriver_win32");
        }

        string username = "xxx";
        string password = "xxx";

        public void Login(string user, string pass)
        {
            driver.FindElement(By.XPath("//*[@id='Username']")).SendKeys(user);
            driver.FindElement(By.XPath("//*[@id='Password']")).SendKeys(pass);
        }

        [Test]
        public void Test()
        {
            driver.Url = "http://www.test.com";
            Login(username, password);
            driver.FindElement(By.XPath("//*[@id='loginButton']")).Click();
        }

        [TearDown]
        public void CloseBrowser()
        {
            driver.Close();
        }
    }
}
